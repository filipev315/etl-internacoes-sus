from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from scripts.etl import run_etl

with DAG('etl_sus',
         schedule_interval='@daily',
         start_date=datetime(2024, 1, 1),
         catchup=False) as dag:

    etl_task = PythonOperator(
        task_id='run_etl',
        python_callable=run_etl
    )
