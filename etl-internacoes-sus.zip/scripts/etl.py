import pandas as pd
from sqlalchemy import create_engine

def run_etl():
    df = pd.read_csv('data/SIH-RJ-Internacoes.csv', sep=';', encoding='latin1')
    df.columns = [col.strip().lower().replace(" ", "_") for col in df.columns]
    df = df.dropna(subset=['municipio', 'internacoes'])
    df['internacoes'] = df['internacoes'].astype(int)
    df_grouped = df.groupby('municipio')['internacoes'].sum().reset_index()

    engine = create_engine("postgresql://airflow:airflow@postgres:5432/saude")
    df_grouped.to_sql("internacoes_por_municipio", engine, if_exists='replace', index=False)
